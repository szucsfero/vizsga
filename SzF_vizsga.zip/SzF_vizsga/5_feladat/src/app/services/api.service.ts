import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  srcURL = 'https://jsonplaceholder.typicode.com/com/photos'  
  constructor(private myHttp: HttpClient) { }
  getData() {
    return this.myHttp.get(this.srcURL);
  }
}
