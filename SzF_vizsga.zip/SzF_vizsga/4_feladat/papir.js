'use strict';
function getCalc(){
    
    const szelesseg=document.getElementById('szelesseg').value;
    const magassag=document.getElementById('magassag').value;
    const papir=document.getElementById('papirtipus').value;
    
    let terulet=Math.round((szelesseg*magassag)/10000);    
    let koltseg=terulet*papir;
    
    document.getElementById('terulet').textContent = terulet;
    document.getElementById('koltseg').textContent = koltseg;

    if (szelesseg < 50 || magassag < 50) {
        alert('Ellenőrizze az adatokat!');
    }

    if (koltseg > 500) {
        document.getElementById('koltseg').style.backgroundColor = '#fff';
        document.getElementById('koltseg').style.color = 'red';
        document.getElementById('koltseg').style.fontWeight = 'bold';
    } else {
        document.getElementById('koltseg').style.backgroundColor = '#fff';
        document.getElementById('koltseg').style.color = 'green';
        document.getElementById('koltseg').style.fontWeight = 'bold';        
    }
}